# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('mantis')

from mantis_lib import Window
from mantis.AboutMantisDialog import AboutMantisDialog
from mantis.PreferencesMantisDialog import PreferencesMantisDialog

# See mantis_lib.Window.py for more details about how this class works
class MantisWindow(Window):
    __gtype_name__ = "MantisWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(MantisWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutMantisDialog
        self.PreferencesDialog = PreferencesMantisDialog

        # Code for other initialization actions should be added here.

        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.homebutton = self.builder.get_object('homebutton')
        self.backbutton = self.builder.get_object('backbutton')
        self.forwardbutton = self.builder.get_object('forwardbutton')
        self.refreshbutton = self.builder.get_object('refreshbutton')
        self.entry1 = self.builder.get_object('entry1')
        self.attsbutton = self.builder.get_object('attsbutton')
        self.updatebutton = self.builder.get_object('updatebutton')

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('http://mantis.zohosites.com/')
        self.webview.open(home)

    def on_entry1_activate(self, widget):
        url = self.entry1.get_text()
        url = str(url)
        self.webview.open(url)

    def on_homebutton_clicked(self, widget):
        home = str('http://mantis.zohosites.com/')
        self.webview.open(home)

    def on_backbutton_clicked(self, widget):
        os.system('clear')
        self.webview.go_back() 

    def on_forwardbutton_clicked(self, widget):
        os.system('clear')
        self.webview.go_forward() 

    def on_refreshbutton_clicked(self, widget):
        os.system('clear')
        self.webview.reload()

    def on_attsbutton_clicked(self, widget):
        os.system('clear')
        print ('..Activate User Prefs Option..')

    def on_updatebutton_clicked(self, widget):
        os.system('cd ~ && gnome-terminal --title="MANTIS | Package Updates.." -x sh -c "clear && sudo git clone http://github.com/alectramell/mantis.git && clear && sudo dpkg -i ~/mantis/mantis_0.1_all.deb && sudo rm -r ~/mantis/"')

    def on_exitbutton_clicked(self, widget):
        exit()    







